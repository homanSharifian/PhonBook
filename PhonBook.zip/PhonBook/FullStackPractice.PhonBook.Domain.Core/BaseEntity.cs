﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FullStackPractice.PhonBook.Domain.Core
{
    public class BaseEntity
    {
        public int Id { get; set; }
    }
}
