﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FullStackPractice.PhonBook.Domain.Core.Tags
{
    public class Tag:BaseEntity
    {
        public string Name { get; set; }
    }
}
