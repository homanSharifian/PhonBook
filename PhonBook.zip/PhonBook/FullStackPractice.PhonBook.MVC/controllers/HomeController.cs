﻿using FullStackPractice.PhonBook.Domain.Contracts.People;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FullStackPractice.PhonBook.MVC.controllers
{
    public class HomeController:Controller
    {
        private readonly IPersonRepository personRepository;
        public HomeController(IPersonRepository personRepository)
        {
            this.personRepository = personRepository;
        }
        public IActionResult index()
        {
            return View();
        }
    }
}
