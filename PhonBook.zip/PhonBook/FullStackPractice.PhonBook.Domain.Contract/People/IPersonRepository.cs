﻿using FullStackPractice.PhonBook.Domain.Contracts.Common;
using FullStackPractice.PhonBook.Domain.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace FullStackPractice.PhonBook.Domain.Contracts.People
{
    public interface IPersonRepository:IBaseRepository<Person>
    {
    }
}
