﻿using FullStackPractice.PhonBook.Domain.Contracts.Common;
using FullStackPractice.PhonBook.Domain.Core.Tags;
using System;
using System.Collections.Generic;
using System.Text;

namespace FullStackPractice.PhonBook.Domain.Contracts.Tags
{
    public interface ITagRepository:IBaseRepository<Tag>
    {
    }
}
