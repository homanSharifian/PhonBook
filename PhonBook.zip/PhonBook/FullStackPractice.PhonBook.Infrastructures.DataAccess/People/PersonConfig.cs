﻿using FullStackPractice.PhonBook.Domain.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace FullStackPractice.PhonBook.Infrastructures.DataAccess.People
{
    class PersonConfig:IEntityTypeConfiguration<Person>
    {
        public void Configure (EntityTypeBuilder<Person> builder)
        {
            builder.Property(c => c.FirstName).HasMaxLength(50).IsRequired();
            builder.Property(c => c.LastName).HasMaxLength(50).IsRequired();
            builder.Property(c => c.Image).IsUnicode(false);
            builder.Property(c => c.Email).HasMaxLength(256).IsRequired();
            builder.Property(c => c.Address).HasMaxLength(500);
            builder.Property(c => c.phoneNumber).HasMaxLength(11);
        }
    }
}
