﻿using FullStackPractice.PhonBook.Domain.Contracts.People;
using FullStackPractice.PhonBook.Domain.Core;
using FullStackPractice.PhonBook.Infrastructures.DataAccess.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace FullStackPractice.PhonBook.Infrastructures.DataAccess.People
{
    public class PersonRepository:BaseRepository<Person>,IPersonRepository
    {
        public PersonRepository(PhonBookContext dbContex):base(dbContex)
        {

        }
    }
}
