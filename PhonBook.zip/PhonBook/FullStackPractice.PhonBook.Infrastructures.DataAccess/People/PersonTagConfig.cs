﻿using FullStackPractice.PhonBook.Domain.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace FullStackPractice.PhonBook.Infrastructures.DataAccess.People
{
    internal class PersonTagConfig:IEntityTypeConfiguration<PersonTag>
    {
        public void Configure(EntityTypeBuilder<PersonTag> builder)
        {

        }
    }
}
