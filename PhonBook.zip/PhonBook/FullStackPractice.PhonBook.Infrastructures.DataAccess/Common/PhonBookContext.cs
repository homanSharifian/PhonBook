﻿using FullStackPractice.PhonBook.Domain.Core;
using FullStackPractice.PhonBook.Domain.Core.Tags;
using FullStackPractice.PhonBook.Infrastructures.DataAccess.People;
using Microsoft.EntityFrameworkCore;
using FullStackPractice.PhonBook.Infrastructures;
using System;
using System.Collections.Generic;
using System.Text;


namespace FullStackPractice.PhonBook.Infrastructures.DataAccess.Common
{
    public class PhonBookContext:DbContext
    {
        public DbSet<Tag> Tags { get; set; }
        public DbSet<Person> People { get; set; }
        public DbSet<PersonTag> PersonTags { get; set; }
        public PhonBookContext(DbContextOptions<PhonBookContext> option):base(option)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new PersonConfig());
            modelBuilder.ApplyConfiguration(new PersonTagConfig());
            base.OnModelCreating(modelBuilder);

        }
    }
}
