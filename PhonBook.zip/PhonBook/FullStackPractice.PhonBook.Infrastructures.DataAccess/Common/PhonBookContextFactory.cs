﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using System;
using System.Collections.Generic;
using System.Text;

namespace FullStackPractice.PhonBook.Infrastructures.DataAccess.Common
{
    public class PhonBookContextFactory:IDesignTimeDbContextFactory<PhonBookContext>
    {
        public PhonBookContext CreateDbContext(string[] arg)
        {
            var builder = new DbContextOptionsBuilder<PhonBookContext>();
            builder.UseSqlServer("Data Source=.;DataBase=PhonBookDB;Integrated Security=True");
            return new PhonBookContext(builder.Options);
        }
    }
}
