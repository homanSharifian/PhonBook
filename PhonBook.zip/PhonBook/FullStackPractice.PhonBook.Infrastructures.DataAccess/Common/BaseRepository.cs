﻿using FullStackPractice.PhonBook.Domain.Contracts.Common;
using FullStackPractice.PhonBook.Domain.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace FullStackPractice.PhonBook.Infrastructures.DataAccess.Common
{
    public abstract class BaseRepository<TEntity>: IBaseRepository<TEntity> where TEntity:BaseEntity,new()
    {
        private readonly PhonBookContext dbContext;
        public BaseRepository(PhonBookContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public TEntity Add(TEntity entity)
        {
            dbContext.Set<TEntity>().Add(entity);
            dbContext.SaveChanges();
            return entity;
        }

        public void Delete(int id)
        {
            TEntity entity = new TEntity
            {
                Id = id
            };
            dbContext.Remove(entity);
            dbContext.SaveChanges();
        }

        public TEntity Get(int id)
        {
            return dbContext.Set<TEntity>().Find(id);
        }

        public IQueryable<TEntity> GetAll()
        {
            return dbContext.Set<TEntity>().AsQueryable();
        }

    }
}
