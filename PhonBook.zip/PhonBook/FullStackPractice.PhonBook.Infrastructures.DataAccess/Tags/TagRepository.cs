﻿using FullStackPractice.PhonBook.Domain.Contracts.Tags;
using FullStackPractice.PhonBook.Domain.Core.Tags;
using FullStackPractice.PhonBook.Infrastructures.DataAccess.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace FullStackPractice.PhonBook.Infrastructures.DataAccess.Tags
{
    public class TagRepository:BaseRepository<Tag>,ITagRepository
    {
        public TagRepository(PhonBookContext dbContext) : base(dbContext)
        {

        }
    }
}
